# AI Solutions Consulting

## Netlify Deployment Instructions

To support SPA routing on Netlify, ensure the following:

1. Place a `_redirects` file in the `public/` directory with this content:

   ```txt
   # SPA fallback rule for client-side routing
   /* /index.html 200
   ```

2. This ensures that routes like `/services` or `/about` do not 404 and instead resolve correctly through your frontend router.

3. Some browsers block automatic meta-refresh in `404.html`, so it's helpful to also provide a manual link back to `/` in your 404 page (if used).

---

## Local Development

```bash
npm install
npm run dev
```

## Production Build

```bash
npm run build
```

Ensure the `public/_redirects` file is present before deploying to Netlify.
