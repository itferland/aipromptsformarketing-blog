# ThinkPrompt

ThinkPrompt is a curated library of powerful AI prompts designed for creators, marketers, developers, and dreamers. Our goal is to help you supercharge your workflow with ready-to-use commands for various AI tools and platforms.

## ✨ Features

*   A growing collection of prompts across diverse categories:
    *   Text Prompts (Copywriting, Idea Generation, SEO, etc.)
    *   Image Prompts (Midjourney, DALL·E, Firefly, etc.)
    *   Music Prompts (Suno, Boomy, AIVA, etc.)
    *   Video Prompts (Runway, Pika, etc.)
    *   Project Builders & How-to Guides
    *   Instructional Prompts
    *   Prompt Gems (Journals, World-Builders, Games, etc.)
*   Organized by categories and tags for easy discoverability.
*   Includes guidance on prompt engineering (see `about.md`).

## 🛠 Tech Stack

This website is built as a static site using [Jekyll](https://jekyllrb.com/). Prompts are stored as Markdown files.
