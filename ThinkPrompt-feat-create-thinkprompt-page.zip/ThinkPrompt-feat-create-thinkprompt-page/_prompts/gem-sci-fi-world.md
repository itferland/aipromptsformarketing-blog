---
title: Invent a Sci-Fi Planet
tool: AI Storyteller
tags: [gem, worldbuilding, scifi, creativewriting, fiction]
category: gem
---

Act as a sci-fi novelist and invent a planet named 'Xylos'. Detail the following aspects:

1.  **Basic Planetary Information:**
    *   Star system (e.g., binary star, proximity to a nebula).
    *   Size and gravity compared to Earth.
    *   Length of day and year.
    *   Number of moons, if any.

2.  **Ecosystems:**
    *   Describe at least two unique biomes (e.g., crystal forests, acidic oceans, floating islands).
    *   Detail unique flora (e.g., bioluminescent, sentient plants, silicon-based trees).
    *   Detail unique fauna (e.g., creatures that communicate via light patterns, energy beings, giant subterranean worms).

3.  **Dominant Sentient Species & Culture:**
    *   Physical appearance and unique biological traits.
    *   Form of government or social structure (e.g., hive-mind, council of elders, AI-governed).
    *   Primary values, beliefs, and traditions.
    *   Level of technological advancement (e.g., spacefaring, FTL travel, biological engineering, energy manipulation).
    *   Architectural style and typical settlement types.

4.  **Technology:**
    *   Examples of everyday technology.
    *   Unique or advanced technologies specific to this planet/species.

5.  **Political Conflict / Plot Hook:**
    *   Describe a brewing political conflict, societal issue, or external threat. Examples:
        *   Resource scarcity leading to internal faction wars.
        *   An ideological divide threatening to split the society.
        *   First contact with a potentially hostile alien race.
        *   An ancient planetary threat re-awakening.

Provide the description in a narrative or encyclopedic style, suitable for a sci-fi world-building bible.
