---
title: Build a Portfolio Website
tool: ChatGPT
tags: [project, instructional, webdev, html, css, javascript]
category: instructional
---

Give me a step-by-step guide to build a personal portfolio website using HTML, CSS, and JavaScript, targeting a beginner developer. The guide should include:

1.  **Setup:**
    *   Basic project structure (folders for HTML, CSS, JS, images).
    *   Essential HTML boilerplate.
    *   Linking CSS and JavaScript files.

2.  **Content Sections (HTML Structure & Basic Styling):**
    *   Homepage (Hero section with name, title, brief intro).
    *   About Me section.
    *   Projects section (placeholder for 2-3 projects with descriptions and links).
    *   Contact section (simple contact form or links to social media).

3.  **Styling (CSS):**
    *   Tips for a clean, modern, and responsive design.
    *   Basic layout techniques (Flexbox/Grid).
    *   Styling for navigation, sections, and project cards.

4.  **Interactivity (JavaScript - Optional, simple examples):**
    *   A simple image slideshow for projects.
    *   Smooth scrolling for navigation links.

5.  **Coding Best Practices:**
    *   Semantic HTML.
    *   Readable CSS.
    *   Comments in code.

6.  **Deployment Steps:**
    *   How to deploy the website to GitHub Pages.
