# Prompt Engineering Guide

Welcome to the ThinkPrompt Prompt Engineering Guide! This guide provides tips and templates to help you craft effective prompts for various AI tools.

## General Tips for Prompting

*   **Be Specific:** The more detail you provide, the better the AI can understand your request.
*   **Define the Persona:** Tell the AI to act as a specific character or expert (e.g., "Act as a senior copywriter").
*   **Provide Context:** Give background information relevant to your task.
*   **Specify the Format:** Ask for the output in a particular format (e.g., "Provide the answer as a bulleted list," "Write a blog post with a friendly tone").
*   **Iterate:** Don't expect the perfect result on the first try. Refine your prompt based on the output.

## Instructional Prompts

Instructional prompts are designed to generate step-by-step guides, tutorials, technical documentation, project breakdowns, and similar content.

**Template:**
```
"Give me a step-by-step guide to build [PROJECT TYPE] using [TECH STACK], targeting [AUDIENCE LEVEL], and include setup, coding, and deployment steps."
```

**Example Usage:**
"Give me a step-by-step guide to build a personal blog using Python Flask, targeting intermediate developers, and include setup, coding for CRUD operations, and deployment steps to Heroku."

## Prompt Gems

Prompt Gems are for more creative and niche use cases. Think journaling systems, fantasy world-building, interactive games, and unique problem-solving scenarios.

**Template:**
```
"Act as a sci-fi novelist and invent a planet with unique ecosystems, technology, and culture. Include a political conflict for the plot."
```

**Example Usage:**
"Act as a fantasy cartographer and design a map for a newly discovered continent. Detail its major geographical features (mountains, rivers, forests), climates, and the locations of three distinct civilizations with brief descriptions of their cultures."

---
*Explore the [Prompt Library](/#library) for more examples!*
