# AI Solutions Consulting

## Netlify SPA Routing Instructions

To support SPA-style client-side routing (e.g., /services, /about), follow these steps:

1. Place a `_redirects` file inside the `public/` directory with this content:

   ```txt
   # SPA fallback rule for Netlify (ensures routes like /services work)
   /* /index.html 200
   ```

2. This file **must be plain text** — no extension (not `.txt` or `.md`)
3. Run `npm run build`. Vite will copy `_redirects` from `public/` into `dist/`
4. Redeploy to Netlify if routing still fails

---

## 404 Page Behavior

The included `public/404.html` page contains:
- A user-friendly message
- A timed redirect back to `/`
- A manual link in case the browser blocks auto-refresh

---

## Local Development

```bash
npm install
npm run dev
```

## Production Build

```bash
npm run build
```
